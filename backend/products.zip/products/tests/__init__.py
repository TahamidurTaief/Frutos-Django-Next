# tests package for products
