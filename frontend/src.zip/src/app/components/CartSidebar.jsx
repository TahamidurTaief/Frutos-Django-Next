// 'use client'

// import { useEffect, useRef } from 'react'
// import Image from 'next/image'
// import Link from 'next/link'
// import { useRouter } from 'next/navigation'
// import { useCart } from '@/app/context/CartContext'

// export default function CartSidebar() {
//   const { items, subtotal, totalItems, sidebarOpen, setSidebarOpen, updateQty, removeItem } = useCart()
//   const router = useRouter()
//   const overlayRef = useRef(null)

//   // Lock body scroll when open
//   useEffect(() => {
//     document.body.style.overflow = sidebarOpen ? 'hidden' : ''
//     return () => { document.body.style.overflow = '' }
//   }, [sidebarOpen])

//   function handleCheckout() {
//     setSidebarOpen(false)
//     router.push('/basket')
//   }

//   return (
//     <>
//       {/* Backdrop */}
//       <div
//         ref={overlayRef}
//         onClick={() => setSidebarOpen(false)}
//         className="fixed inset-0 z-40 bg-black/20 backdrop-blur-sm transition-opacity duration-300"
//         style={{
//           opacity: sidebarOpen ? 1 : 0,
//           pointerEvents: sidebarOpen ? 'auto' : 'none',
//         }}
//       />

//       {/* Drawer */}
//       <aside
//         className="fixed top-0 right-0 h-full z-50 flex flex-col"
//         style={{
//           width: 'min(440px, 100vw)',
//           background: '#ffffff',
//           boxShadow: '-24px 0 80px rgba(0,33,21,0.12)',
//           transform: sidebarOpen ? 'translateX(0)' : 'translateX(100%)',
//           transition: 'transform 0.35s cubic-bezier(0.32, 0.72, 0, 1)',
//         }}
//       >
//         {/* Header */}
//         <div className="flex items-center justify-between px-6 py-5 border-b border-[#bccac1]/30">
//           <div>
//             <p className="text-[10px] font-bold uppercase tracking-[0.2em] text-[#6d7a73]">
//               Your Basket
//             </p>
//             <h2
//               className="text-2xl italic leading-tight"
//               style={{ fontFamily: '"Newsreader", Georgia, serif' }}
//             >
//               {totalItems} {totalItems === 1 ? 'item' : 'items'}
//             </h2>
//           </div>
//           <button
//             onClick={() => setSidebarOpen(false)}
//             className="w-10 cursor-pointer h-10 flex items-center justify-center rounded-full hover:bg-[#f0f4f0] transition-colors"
//           >
//             <span className="material-symbols-outlined text-[#3d4943]">close</span>
//           </button>
//         </div>

//         {/* Items list */}
//         <div className="flex-1 overflow-y-auto px-6 py-6 space-y-6">
//           {items.length === 0 ? (
//             <div className="flex flex-col items-center justify-center h-full gap-4 text-center py-16">
//               <span className="material-symbols-outlined text-5xl text-[#bccac1]">
//                 shopping_basket
//               </span>
//               <p
//                 className="text-xl italic text-[#6d7a73]"
//                 style={{ fontFamily: '"Newsreader", Georgia, serif' }}
//               >
//                 Your basket is empty
//               </p>
//               <p className="text-sm text-[#6d7a73]">
//                 Add something fresh from the market
//               </p>
//               <button
//                 onClick={() => setSidebarOpen(false)}
//                 className="mt-2 cursor-pointer px-6 py-3 rounded-full border border-[#00694c]/30 text-[#00694c] text-sm font-bold hover:bg-[#f0f4f0] transition-colors"
//               >
//                 Browse Market
//               </button>
//             </div>
//           ) : (
//             items.map(item => (
//               <div key={item.id} className="flex gap-4 group">
//                 <div className="w-20 h-20 rounded-xl overflow-hidden flex-shrink-0 bg-white">
//                   <Image
//                     src={item.image}
//                     alt={item.name}
//                     width={80}
//                     height={80}
//                     className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
//                   />
//                 </div>
//                 <div className="flex-1 flex flex-col justify-between py-0.5">
//                   <div className="flex items-start justify-between gap-2">
//                     <div>
//                       <h3 className="font-bold text-[#151e13] text-sm leading-tight">
//                         {item.name}
//                       </h3>
//                       <p
//                         className="text-xs italic text-[#00694c] mt-0.5"
//                         style={{ fontFamily: '"Newsreader", Georgia, serif' }}
//                       >
//                         from {item.origin}
//                       </p>
//                     </div>
//                     <button
//                       onClick={() => removeItem(item.id)}
//                       className="cursor-pointer text-[#bccac1] hover:text-[#ba1a1a] transition-colors mt-0.5"
//                     >
//                       <span className="material-symbols-outlined text-[18px]">close</span>
//                     </button>
//                   </div>

//                   <div className="flex items-center justify-between mt-2">
//                     {/* Qty stepper */}
//                     <div className="flex items-center bg-[#f0f4f0] rounded-lg p-0.5">
//                       <button
//                         onClick={() => updateQty(item.id, item.qty - 1)}
//                         className="w-7 cursor-pointer h-7 flex items-center justify-center hover:bg-[#e2e8e2] rounded transition-colors"
//                       >
//                         <span className="material-symbols-outlined text-[16px]">remove</span>
//                       </button>
//                       <span className="w-7 text-center font-bold text-sm">{item.qty}</span>
//                       <button
//                         onClick={() => updateQty(item.id, item.qty + 1)}
//                         className="w-7 cursor-pointer h-7 flex items-center justify-center hover:bg-[#e2e8e2] rounded transition-colors"
//                       >
//                         <span className="material-symbols-outlined text-[16px]">add</span>
//                       </button>
//                     </div>
//                     <span className="font-bold text-[#855000] text-sm">
//                       €{(item.price * item.qty).toFixed(2)}
//                     </span>
//                   </div>
//                 </div>
//               </div>
//             ))
//           )}
//         </div>

//         {/* Footer */}
//         {items.length > 0 && (
//           <div className="px-6 py-6 border-t border-[#bccac1]/30 space-y-4 bg-[#f5f9f5]">
//             {/* Subtotal */}
//             <div className="flex items-center justify-between">
//               <span className="text-sm text-[#6d7a73]">Subtotal</span>
//               <span className="font-bold text-[#151e13]">€{subtotal.toFixed(2)}</span>
//             </div>
//             <div className="flex items-center justify-between">
//               <span className="text-sm text-[#6d7a73]">Delivery</span>
//               <div className="flex items-center gap-2">
//                 <span className="bg-[#adedd8] text-[#095041] text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-full">
//                   Free
//                 </span>
//                 <span className="font-bold text-[#00694c]">€0.00</span>
//               </div>
//             </div>

//             <div className="pt-3 border-t border-[#bccac1]/30 flex items-end justify-between">
//               <span className="font-bold text-[#151e13] uppercase tracking-tight text-sm">Total</span>
//               <div className="text-right">
//                 <p
//                   className="text-2xl font-bold text-[#855000]"
//                   style={{ fontFamily: '"Newsreader", Georgia, serif' }}
//                 >
//                   €{subtotal.toFixed(2)}
//                 </p>
//                 <p className="text-[10px] text-[#6d7a73] uppercase tracking-widest">VAT included</p>
//               </div>
//             </div>

//             {/* CTA */}
//             <button
//               onClick={handleCheckout}
//               className="w-full cursor-pointer flex items-center justify-center gap-3 py-4 rounded-xl font-bold text-white transition-all hover:brightness-105 active:scale-[0.98]"
//               style={{
//                 background: 'linear-gradient(135deg, #00694c 0%, #008560 100%)',
//                 boxShadow: '0 8px 24px -4px rgba(0,105,76,0.3)',
//               }}
//             >
//               View Basket & Checkout
//               <span className="material-symbols-outlined">arrow_forward</span>
//             </button>

//             <div className="flex justify-center items-center gap-4 opacity-40 grayscale">
//               <span className="material-symbols-outlined text-2xl">credit_card</span>
//               <span className="material-symbols-outlined text-2xl">verified_user</span>
//               <span className="material-symbols-outlined text-2xl">payments</span>
//             </div>
//           </div>
//         )}
//       </aside>
//     </>
//   )
// }

'use client'

import { useEffect, useRef, useState } from 'react'
import Image from 'next/image'
import Link from 'next/link'
import { useRouter } from 'next/navigation'
import { useCart } from '@/app/context/CartContext'
import toast from 'react-hot-toast'

const API_BASE = process.env.NEXT_PUBLIC_API_URL

function calcDeliveryFee(config, subtotal) {
  if (!config || !config.is_active || config.charge_type === 'free') return 0
  if (config.charge_type === 'flat') return Number(config.flat_fee)
  if (config.charge_type === 'threshold') {
    return subtotal >= Number(config.free_threshold) ? 0 : Number(config.flat_fee)
  }
  return 0
}

export default function CartSidebar() {
  const { items, subtotal, totalItems, sidebarOpen, setSidebarOpen, updateQty, removeItem } = useCart()
  const router = useRouter()
  const overlayRef = useRef(null)

  // ── Delivery config ───────────────────────────────────────────────────────
  const [deliveryConfig, setDeliveryConfig] = useState(null)
  const [popup, setPopup] = useState(false)

  useEffect(() => {
    fetch(`${API_BASE}/delivery-charge/`, { cache: 'no-store' })
      .then(r => r.ok ? r.json() : null)
      .then(data => setDeliveryConfig(data))
      .catch(() => { })
  }, [])

  const deliveryFee = calcDeliveryFee(deliveryConfig, subtotal)
  const grandTotal = subtotal + deliveryFee
  // ─────────────────────────────────────────────────────────────────────────

  useEffect(() => {
    document.body.style.overflow = sidebarOpen ? 'hidden' : ''
    return () => { document.body.style.overflow = '' }
  }, [sidebarOpen])

  const violatingItems = items.filter(item => item.qty < (parseInt(item.minimum_purchase) || parseInt(item.minWholesaleQty) || 1))

  function handleCheckout() {
    if (violatingItems.length > 0) {
      setPopup(true)
      return
    }
    setSidebarOpen(false)
    router.push('/basket')
  }

  return (
    <>
      {/* Backdrop */}
      <div
        ref={overlayRef}
        onClick={() => setSidebarOpen(false)}
        className="fixed inset-0 z-40 bg-black/20 backdrop-blur-sm transition-opacity duration-300"
        style={{ opacity: sidebarOpen ? 1 : 0, pointerEvents: sidebarOpen ? 'auto' : 'none' }}
      />

      {/* Drawer */}
      <aside
        className="fixed top-0 right-0 h-full z-50 flex flex-col"
        style={{
          width: 'min(440px, 100vw)',
          background: '#ffffff',
          boxShadow: '-24px 0 80px rgba(0,33,21,0.12)',
          transform: sidebarOpen ? 'translateX(0)' : 'translateX(100%)',
          transition: 'transform 0.35s cubic-bezier(0.32, 0.72, 0, 1)',
        }}
      >
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-5 border-b border-[#bccac1]/30">
          <div>
            <p className="text-[10px] font-bold uppercase tracking-[0.2em] text-[#6d7a73]">Your Basket</p>
            <h2 className="text-2xl italic leading-tight" style={{ fontFamily: '"Newsreader", Georgia, serif' }}>
              {totalItems} {totalItems === 1 ? 'item' : 'items'}
            </h2>
          </div>
          <button
            onClick={() => setSidebarOpen(false)}
            className="w-10 cursor-pointer h-10 flex items-center justify-center rounded-full hover:bg-[#f0f4f0] transition-colors"
          >
            <span className="material-symbols-outlined text-[#3d4943]">close</span>
          </button>
        </div>

        {/* Items list and Footer */}
        <div className="flex-1 overflow-y-auto flex flex-col">
          <div className="px-4 sm:px-5 py-3 sm:py-4 flex-1">
            {items.length === 0 ? (
              <div className="flex flex-col items-center justify-center h-full gap-3 text-center py-12 sm:py-16">
                <span className="material-symbols-outlined text-4xl text-[#bccac1]">shopping_basket</span>
                <p className="text-lg sm:text-xl italic text-[#6d7a73]" style={{ fontFamily: '"Newsreader", Georgia, serif' }}>
                  Your basket is empty
                </p>
                <p className="text-xs sm:text-sm text-[#6d7a73]">Add something fresh from the market</p>
                <button
                  onClick={() => setSidebarOpen(false)}
                  className="mt-2 cursor-pointer px-5 sm:px-6 py-2.5 rounded-full border border-[#00694c]/30 text-[#00694c] text-sm font-bold hover:bg-[#f0f4f0] transition-colors"
                >
                  Browse Market
                </button>
              </div>
            ) : (
              <div className="space-y-0">
                {items.map((item, index) => {
                  const mediaBase = API_BASE.replace('/api', '')
                  let imageUrl = item.image || item.thumbnail || item.image_url || null
                  if (imageUrl && !imageUrl.startsWith('http') && !imageUrl.startsWith('data:')) {
                    const clean = imageUrl.replace(/^\/+/, '')
                    imageUrl = `${mediaBase}/${clean}`
                  }

                  return (
                    <div key={item.id} className={`flex gap-3 group items-center py-3 sm:py-4 ${index !== items.length - 1 ? 'border-b border-[#bccac1]/30' : ''}`}>
                      <div className="w-14 h-14 sm:w-16 sm:h-16 rounded-lg overflow-hidden flex-shrink-0 bg-white shadow-sm border border-gray-100">
                        {imageUrl ? (
                          <Image
                            src={imageUrl} alt={item.name} width={64} height={64}
                            className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                          />
                        ) : (
                          <div className="w-full h-full bg-[#f0f4f0] flex items-center justify-center">
                            <span className="material-symbols-outlined text-[#bccac1] text-lg">image</span>
                          </div>
                        )}
                      </div>
                      <div className="flex-1 flex flex-col justify-center">
                        <div className="flex items-start justify-between gap-2">
                          <div className="pr-2">
                            <h3 className="font-bold text-[#151e13] text-[13px] sm:text-sm leading-none">{item.name}</h3>
                            <p className="text-[11px] sm:text-xs italic text-[#00694c] mt-1" style={{ fontFamily: '"Newsreader", Georgia, serif' }}>
                              from {item.origin}
                            </p>
                          </div>
                          <button onClick={() => removeItem(item.id, item.item_type || 'product')} className="cursor-pointer text-[#bccac1] hover:text-[#ba1a1a] transition-colors p-1 -m-1">
                            <span className="material-symbols-outlined text-[16px] sm:text-[18px]">close</span>
                          </button>
                        </div>
                        <div className="flex items-center justify-between mt-2 sm:mt-2.5">
                          <div className="flex items-center bg-[#f0f4f0] rounded-md p-0.5">
                            {(() => {
                              const minQty = parseInt(item.minimum_purchase) || parseInt(item.minWholesaleQty) || 1;
                              const disabled = item.qty <= minQty;
                              return (
                                <button onClick={() => updateQty(item.id, Math.max(minQty, item.qty - 1), item.item_type || 'product')}
                                  disabled={disabled}
                                  className={`w-6 h-6 flex items-center justify-center rounded transition-colors ${disabled ? 'text-gray-400 cursor-not-allowed' : 'cursor-pointer hover:bg-[#e2e8e2]'}`}>
                                  <span className="material-symbols-outlined text-[14px]">remove</span>
                                </button>
                              );
                            })()}
                            <span className="w-6 text-center font-bold text-[13px]">{item.qty}</span>
                            <button onClick={() => updateQty(item.id, item.stock !== undefined && item.stock !== null ? Math.min(item.stock, item.qty + 1) : item.qty + 1, item.item_type || 'product')}
                              disabled={item.stock !== undefined && item.stock !== null && item.qty >= item.stock}
                              className={`w-6 h-6 flex items-center justify-center rounded transition-colors ${item.stock !== undefined && item.stock !== null && item.qty >= item.stock ? 'invisible' : 'cursor-pointer hover:bg-[#e2e8e2]'}`}>
                              <span className="material-symbols-outlined text-[14px]">add</span>
                            </button>
                          </div>
                          <span className="font-bold text-[#855000] text-[13px] sm:text-sm">
                            €{((item.effectivePrice ?? item.price) * item.qty).toFixed(2)}
                          </span>
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>

          {/* Footer */}
          {items.length > 0 && (
            <div className="px-4 sm:px-5 py-4 sm:py-5 border-t border-[#bccac1]/50 space-y-2 sm:space-y-3 bg-[#f8faf8] mt-auto">

              {/* Subtotal */}
              <div className="flex items-center justify-between">
                <span className="text-[12px] sm:text-[13px] text-[#6d7a73]">Subtotal</span>
                <span className="font-bold text-[#151e13] text-[13px] sm:text-sm">€{subtotal.toFixed(2)}</span>
              </div>

              {/* ── Delivery row — এখন dynamic ── */}
              <div className="flex items-center justify-between">
                <span className="text-[12px] sm:text-[13px] text-[#6d7a73]">Delivery</span>
                {deliveryFee === 0 ? (
                  <div className="flex items-center gap-2">
                    <span className="bg-[#adedd8] text-[#095041] text-[9px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-full">
                      Free
                    </span>
                    <span className="font-bold text-[#00694c] text-[13px] sm:text-sm">€0.00</span>
                  </div>
                ) : (
                  <span className="font-bold text-[#151e13] text-[13px] sm:text-sm">€{deliveryFee.toFixed(2)}</span>
                )}
              </div>

              {/* Threshold hint */}
              {deliveryConfig?.charge_type === 'threshold' && deliveryFee > 0 && (
                <p className="text-[10px] italic text-[#6d7a73]">
                  Spend €{(Number(deliveryConfig.free_threshold) - subtotal).toFixed(2)} more for free delivery
                </p>
              )}

              {/* Total — এখন grandTotal use করছে */}
              <div className="pt-2 border-t border-[#bccac1]/30 flex items-end justify-between mt-2">
                <span className="font-bold text-[#151e13] uppercase tracking-tight text-[12px] sm:text-[13px]">Total</span>
                <div className="text-right">
                  <p className="text-xl sm:text-2xl font-bold text-[#855000]" style={{ fontFamily: '"Newsreader", Georgia, serif' }}>
                    €{grandTotal.toFixed(2)}
                  </p>
                  <p className="text-[9px] text-[#6d7a73] uppercase tracking-widest mt-0.5">VAT included</p>
                </div>
              </div>

              {/* CTA */}
              <button
                onClick={handleCheckout}
                className="w-full cursor-pointer flex items-center justify-center gap-2 sm:gap-3 py-3 rounded-xl font-bold text-white text-[13px] sm:text-sm transition-all hover:brightness-105 active:scale-[0.98] mt-3"
                style={{
                  background: 'linear-gradient(135deg, #00694c 0%, #008560 100%)',
                  boxShadow: '0 4px 14px -2px rgba(0,105,76,0.2)',
                }}
              >
                View Basket & Checkout
                <span className="material-symbols-outlined text-[18px]">arrow_forward</span>
              </button>

              <div className="flex justify-center items-center gap-3 sm:gap-4 opacity-40 grayscale pt-1">
                <span className="material-symbols-outlined text-[18px] sm:text-[20px]">credit_card</span>
                <span className="material-symbols-outlined text-[18px] sm:text-[20px]">verified_user</span>
                <span className="material-symbols-outlined text-[18px] sm:text-[20px]">payments</span>
              </div>
            </div>
          )}
        </div>
      </aside>

      {/* ── Wholesale popup ────────────────────────────────────────────────── */}
      {popup && (
        <div className="fixed inset-0 z-[60]" style={{ background: 'rgba(0,0,0,0.35)' }} onClick={() => setPopup(false)} />
      )}
      <div
        className="fixed left-0 right-0 top-0 z-[70] transition-transform duration-300 ease-out"
        style={{ transform: popup ? 'translateY(0)' : 'translateY(-110%)' }}
      >
        <div className="mx-auto max-w-lg rounded-b-3xl px-6 pt-10 pb-6" style={{ background: '#ffffff', boxShadow: '0 8px 40px rgba(0,0,0,0.15)' }}>
          <div className="flex items-start gap-4 mb-5">
            <div className="w-11 h-11 rounded-full flex items-center justify-center flex-shrink-0 mt-0.5" style={{ background: '#FFF3CD' }}>
              <span className="material-symbols-outlined" style={{ color: '#B45309', fontSize: '22px', fontVariationSettings: "'FILL' 1" }}>warning</span>
            </div>
            <div>
              <h3 className="text-lg font-bold" style={{ color: '#151e13' }}>Minimum Quantity Required</h3>
              <p className="text-sm mt-1" style={{ color: '#6d7a73' }}>Update the quantities below to continue.</p>
            </div>
          </div>
          <div className="space-y-3 mb-6">
            {violatingItems.map(item => (
              <div key={item.id} className="flex items-center justify-between rounded-xl px-4 py-3" style={{ background: '#FFF8EE', border: '1px solid #FFE4B2' }}>
                <div>
                  <p className="text-sm font-bold" style={{ color: '#151e13' }}>{item.name}</p>
                  <p className="text-xs mt-0.5" style={{ color: '#B45309' }}>
                    You have {item.qty} — minimum is <span className="font-bold">{item.minWholesaleQty}</span>
                  </p>
                </div>
                <span className="text-xs font-bold px-3 py-1 rounded-full flex-shrink-0" style={{ background: '#FFE4B2', color: '#92400E' }}>
                  +{item.minWholesaleQty - item.qty} needed
                </span>
              </div>
            ))}
          </div>
          <button onClick={() => setPopup(false)} className="w-full py-4 rounded-xl text-sm font-bold cursor-pointer text-white mb-2" style={{ background: 'linear-gradient(135deg, #00694c 0%, #008560 100%)' }}>
            Got it
          </button>
          <div className="w-10 h-1 rounded-full mx-auto mt-4" style={{ background: '#dde8dd' }} />
        </div>
      </div>
    </>
  )
}